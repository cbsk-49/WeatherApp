Place your image assets here.
Expected: Stormclouds.jpg used by Header.

