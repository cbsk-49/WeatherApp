function WeatherCard({ weather }) {
  if (weather.error) {
    return <div className="card"><p className="errordisplay">{weather.error}</p></div>;
  }

  function formatTime(timestamp, timezone) {
    const date = new Date((timestamp + timezone) * 1000);
    const hours = date.getUTCHours().toString().padStart(2, '0');
    const minutes = date.getUTCMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  }

  return (
    <div className="card">
      <h1 className="citydisplay">{weather.name}</h1>
      <img
        src={`https://openweathermap.org/img/wn/${weather.icon}@2x.png`}
        alt="weather icon"
        style={{ width: "100px", height: "100px" }}
      />
      <p className="tempdisplay">{Math.round(weather.temp)}°C</p>
      <p className="descdisplay">{weather.desc.charAt(0).toUpperCase() + weather.desc.slice(1)}</p>

      <div className="details">
        <p><strong>Feels Like:</strong> {Math.round(weather.feels_like)}°C</p>
        <p><strong>Min Temp:</strong> {Math.round(weather.temp_min)}°C</p>
        <p><strong>Max Temp:</strong> {Math.round(weather.temp_max)}°C</p>
        <p><strong>Humidity:</strong> {weather.humidity}%</p>
        <p><strong>Pressure:</strong> {weather.pressure} hPa</p>
        <p><strong>Visibility:</strong> {(weather.visibility / 1000).toFixed(1)} km</p>
        <p><strong>Wind Speed:</strong> {weather.wind} m/s</p>
        <p><strong>Wind Direction:</strong> {weather.wind_deg}°</p>
        <p><strong>Clouds:</strong> {weather.clouds}%</p>

        {weather.sunrise && weather.timezone && (
          <>
            <p><strong>Sunrise:</strong> {formatTime(weather.sunrise, weather.timezone)}</p>
            <p><strong>Sunset:</strong> {formatTime(weather.sunset, weather.timezone)}</p>
          </>
        )}
      </div>
    </div>
  );
}
export default WeatherCard;
